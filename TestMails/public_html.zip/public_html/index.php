<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="sweetalert2.all.min.js"></script>
    <link rel="stylesheet" href="sweetalert2.min.css">
    <title>Mails Con PHP</title>
  </head>
  <body>
    <div class="container-sm">
      <div class="container-fluid">
          <div class="container">
            <div class="row">
              <form action="index.php" method="post">
                <h1 class="">Mails Con PHP</h1>
                <div class="col-8"><br><br><br>
                  <div class="container">
                    <label for="exampleFormControlInput1" class="form-label">Direccion De Correo</label>
                    <input name="email" type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                  </div><br>
                  <div class="container">
                    <label for="exampleFormControlInput1" class="form-label">Asunto/Titulo</label>
                    <input name="asunto" type="text" class="form-control" id="exampleFormControlInput1" placeholder="Informacion/Solicitud/Etc...">
                  </div><br>
                  <div class="container">

                    <label for="exampleFormControlTextarea1" class="form-label">Mensaje</label>
                    <textarea name="mensaje" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div><br>
                  <div class="container">
                    <button type="submit" name="button" class="btn btn-outline-primary">Enviar Mail</button>
                  </div><br>
                </div>
              </form>
            </div>
          </div>
      </div>
    </div>
    <?php
    if (isset($_POST["email"])) {
      $email=$_POST["email"];
      $asunto=$_POST["asunto"];
      $mensaje=$_POST["mensaje"];
      mail($email,$asunto,$mensaje);
      echo '
      Swal.fire(
        "Good job!",
        "You clicked the button!",
        "success"
      )';
    }else {
      echo '
      Swal.fire(
        "NDA!",
        "pailas!",
        "error"
      )';
    } ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>
